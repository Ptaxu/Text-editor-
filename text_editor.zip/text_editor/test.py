from tkinterdnd2 import TkinterDnD, DND_FILES
from customtkinter import *
import tkinter as tk
import os

# Base window using TkinterDnD
class DragDropApp(TkinterDnD.Tk):
    def __init__(self):
        super().__init__()
        self.title("Drag & Drop File Path Viewer")
        self.geometry("500x200")

        # Embed CustomTkinter inside
        CTkLabel(self, text="Drag a file here", font=("Segoe UI", 14)).pack(pady=20)
        self.output = CTkLabel(self, text="", wraplength=480, font=("Segoe UI", 12))
        self.output.pack(pady=10)

        # Enable drag-and-drop
        self.drop_target_register(DND_FILES)
        self.dnd_bind('<<Drop>>', self.on_drop)

    def on_drop(self, event):
        path = event.data.strip("{}")
        if os.path.isfile(path):
            self.output.configure(text=path)
        else:
            self.output.configure(text="Invalid file")

# Run the app
app = DragDropApp()
app.mainloop()